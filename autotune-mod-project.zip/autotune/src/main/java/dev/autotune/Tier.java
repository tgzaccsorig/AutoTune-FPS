package dev.autotune;

import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.particle.ParticlesMode;

/** Уровни настроек. Чем выше балл железа, тем выше уровень. */
public enum Tier {
	POTATO("Картошка", 6, 5, GraphicsMode.FAST, CloudRenderMode.OFF, ParticlesMode.MINIMAL, 0.5, 0, false, false),
	LOW("Слабое", 8, 6, GraphicsMode.FAST, CloudRenderMode.FAST, ParticlesMode.DECREASED, 0.75, 1, false, true),
	MEDIUM("Среднее", 12, 8, GraphicsMode.FANCY, CloudRenderMode.FAST, ParticlesMode.ALL, 1.0, 3, true, true),
	HIGH("Мощное", 16, 12, GraphicsMode.FANCY, CloudRenderMode.FANCY, ParticlesMode.ALL, 1.0, 5, true, true),
	ULTRA("Топ", 24, 16, GraphicsMode.FANCY, CloudRenderMode.FANCY, ParticlesMode.ALL, 1.25, 7, true, true);

	public final String title;
	public final int viewDistance;
	public final int simDistance;
	public final GraphicsMode graphics;
	public final CloudRenderMode clouds;
	public final ParticlesMode particles;
	public final double entityDistance;
	public final int biomeBlend;
	public final boolean entityShadows;
	public final boolean ambientOcclusion;

	Tier(String title, int viewDistance, int simDistance, GraphicsMode graphics, CloudRenderMode clouds,
		 ParticlesMode particles, double entityDistance, int biomeBlend, boolean entityShadows, boolean ambientOcclusion) {
		this.title = title;
		this.viewDistance = viewDistance;
		this.simDistance = simDistance;
		this.graphics = graphics;
		this.clouds = clouds;
		this.particles = particles;
		this.entityDistance = entityDistance;
		this.biomeBlend = biomeBlend;
		this.entityShadows = entityShadows;
		this.ambientOcclusion = ambientOcclusion;
	}

	public static Tier fromScore(int score) {
		if (score < 25) return POTATO;
		if (score < 45) return LOW;
		if (score < 65) return MEDIUM;
		if (score < 82) return HIGH;
		return ULTRA;
	}
}
