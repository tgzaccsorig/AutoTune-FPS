package dev.autotune;

import org.lwjgl.opengl.GL11;

import java.lang.management.ManagementFactory;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Определяет железо и считает баллы 0..100 для видеокарты, процессора и памяти. */
public final class HardwareInfo {
	public final String gpuName;
	public final int cpuThreads;
	public final long physicalRamMb;
	public final long heapMb;
	public final int gpuScore;
	public final int cpuScore;
	public final int ramScore;
	public final int totalScore;

	private HardwareInfo(String gpuName, int cpuThreads, long physicalRamMb, long heapMb) {
		this.gpuName = gpuName;
		this.cpuThreads = cpuThreads;
		this.physicalRamMb = physicalRamMb;
		this.heapMb = heapMb;
		this.gpuScore = scoreGpu(gpuName);
		this.cpuScore = scoreCpu(cpuThreads);
		this.ramScore = scoreRam(physicalRamMb);
		this.totalScore = (int) Math.round(gpuScore * 0.55 + cpuScore * 0.30 + ramScore * 0.15);
	}

	/** Вызывать только из основного (render) потока игры, когда OpenGL уже создан. */
	public static HardwareInfo detect() {
		String gpu = glString(GL11.GL_RENDERER);
		int threads = Math.max(1, Runtime.getRuntime().availableProcessors());
		long heapMb = Runtime.getRuntime().maxMemory() / (1024L * 1024L);
		return new HardwareInfo(gpu, threads, physicalRamMb(heapMb), heapMb);
	}

	/** Строка-«отпечаток» железа: если она изменилась, значит поменялся ПК или видеокарта. */
	public String signature() {
		return gpuName + "|" + cpuThreads + "|" + Math.round(physicalRamMb / 1024.0) + "GB";
	}

	/** Максимальная прорисовка, которую потянет выделенная игре оперативка (куча Java). */
	public int heapViewCap() {
		if (heapMb < 2048) return 8;
		if (heapMb < 3072) return 12;
		if (heapMb < 4096) return 16;
		if (heapMb < 6144) return 20;
		return 32;
	}

	// ------------------------------------------------------------------ detection

	private static String glString(int name) {
		try {
			String s = GL11.glGetString(name);
			return s == null ? "unknown" : s;
		} catch (Throwable t) {
			return "unknown";
		}
	}

	private static long physicalRamMb(long fallbackHeapMb) {
		try {
			java.lang.management.OperatingSystemMXBean os = ManagementFactory.getOperatingSystemMXBean();
			if (os instanceof com.sun.management.OperatingSystemMXBean sun) {
				long total = sun.getTotalMemorySize();
				if (total > 0) return total / (1024L * 1024L);
			}
		} catch (Throwable ignored) {
		}
		return fallbackHeapMb * 2;
	}

	// ------------------------------------------------------------------ scoring

	static int scoreCpu(int threads) {
		if (threads <= 2) return 12;
		if (threads <= 4) return 30;
		if (threads <= 6) return 48;
		if (threads <= 8) return 60;
		if (threads <= 12) return 74;
		if (threads <= 16) return 86;
		return 95;
	}

	static int scoreRam(long mb) {
		double gb = mb / 1024.0;
		if (gb <= 4.5) return 10;
		if (gb <= 6.5) return 25;
		if (gb <= 8.5) return 40;
		if (gb <= 12.5) return 55;
		if (gb <= 16.5) return 70;
		if (gb <= 24.5) return 80;
		return 92;
	}

	private static final Pattern RTX = Pattern.compile("rtx\\s*(\\d{4})");
	private static final Pattern GTX = Pattern.compile("gtx\\s*(\\d{3,4})");
	private static final Pattern GT = Pattern.compile("\\bgt\\s*(\\d{3,4})");
	private static final Pattern RX = Pattern.compile("rx\\s*(\\d{3,4})");
	private static final Pattern ARC = Pattern.compile("\\barc\\b.*?\\b([ab])\\s*(\\d{3})");
	private static final Pattern APPLE_M = Pattern.compile("\\bm(\\d)\\b");

	static int scoreGpu(String rawName) {
		String n = rawName.toLowerCase(Locale.ROOT);
		int score;
		if (n.contains("llvmpipe") || n.contains("softpipe") || n.contains("software") || n.contains("basic render")) {
			score = 3;
		} else if (n.contains("apple")) {
			score = apple(n);
		} else if (n.contains("nvidia") || n.contains("geforce") || n.contains("quadro") || n.contains("rtx") || n.contains("gtx")) {
			score = nvidia(n);
		} else if (n.contains("radeon") || n.contains("amd") || n.contains("ati ")) {
			score = amd(n);
		} else if (n.contains("intel")) {
			score = intel(n);
		} else {
			score = 40; // не узнали — берём середину
		}
		if (n.contains("laptop") || n.contains("mobile") || n.contains("max-q")) score -= 8;
		return Math.max(0, Math.min(100, score));
	}

	private static int nvidia(String n) {
		Matcher m = RTX.matcher(n);
		if (m.find()) {
			int num = Integer.parseInt(m.group(1));
			int gen = num / 1000;               // 2, 3, 4, 5
			int cls = ((num / 10) % 10) * 10;   // 90, 80, 70, 60, 50
			int genPts = switch (gen) {
				case 2 -> 38;
				case 3 -> 48;
				case 4 -> 58;
				case 5 -> 60;
				default -> 50;
			};
			int clsPts = cls >= 90 ? 40 : cls >= 80 ? 34 : cls >= 70 ? 28 : cls >= 60 ? 20 : 12;
			int s = genPts + clsPts;
			if (n.contains(" ti") || n.contains("super")) s += 3;
			return s;
		}
		m = GTX.matcher(n);
		if (m.find()) {
			int num = Integer.parseInt(m.group(1));
			if (num >= 1600) return num >= 1660 ? 58 : 50;      // GTX 16xx
			if (num >= 1000) {                                  // GTX 10xx
				int cls = ((num / 10) % 10) * 10;
				return cls >= 80 ? 64 : cls >= 70 ? 58 : cls >= 60 ? 50 : 40;
			}
			if (num >= 900) return num >= 970 ? 48 : 38;        // GTX 9xx
			return 22;                                          // GTX 7xx и старее
		}
		m = GT.matcher(n);
		if (m.find()) {
			int num = Integer.parseInt(m.group(1));
			return num >= 1030 ? 25 : 15;
		}
		if (n.contains(" mx")) return 22;
		return 35;
	}

	private static int amd(String n) {
		Matcher m = RX.matcher(n);
		if (m.find()) {
			int num = Integer.parseInt(m.group(1));
			if (num >= 1000) {
				int gen = num / 1000;
				int cls = (num / 100) % 10;
				return switch (gen) {
					case 9 -> cls >= 7 ? 92 : 80;
					case 7 -> cls >= 9 ? 95 : cls == 8 ? 88 : cls == 7 ? 80 : cls == 6 ? 70 : 58;
					case 6 -> cls >= 9 ? 86 : cls == 8 ? 83 : cls == 7 ? 74 : cls == 6 ? 64 : cls == 5 ? 46 : 35;
					case 5 -> cls >= 7 ? 60 : cls == 6 ? 54 : cls == 5 ? 44 : 35;
					default -> 50;
				};
			}
			return num >= 580 ? 48 : num >= 570 ? 44 : num >= 560 ? 36 : num >= 550 ? 30 : num >= 470 ? 42 : 30;
		}
		if (n.contains("vega 56") || n.contains("vega 64")) return 52;
		if (n.contains("780m") || n.contains("680m")) return 32;
		if (n.contains("radeon pro")) return 40;
		// «AMD Radeon(TM) Graphics», Vega в процессорах Ryzen и т.п. — встроенная графика
		return 18;
	}

	private static int intel(String n) {
		Matcher m = ARC.matcher(n);
		if (m.find()) {
			String letter = m.group(1);
			int num = Integer.parseInt(m.group(2));
			if (letter.equals("b")) return num >= 580 ? 62 : 58;
			return num >= 770 ? 65 : num >= 750 ? 60 : num >= 580 ? 52 : 35;
		}
		if (n.contains("iris xe")) return 22;
		if (n.contains("iris")) return 20;
		if (n.contains("uhd")) return 14;
		if (n.contains("hd graphics")) return 10;
		return 15;
	}

	private static int apple(String n) {
		int base = 60;
		Matcher m = APPLE_M.matcher(n);
		if (m.find()) {
			int gen = Integer.parseInt(m.group(1));
			base = switch (gen) {
				case 1 -> 55;
				case 2 -> 62;
				case 3 -> 70;
				default -> 76;
			};
		}
		if (n.contains("ultra")) base += 20;
		else if (n.contains("max")) base += 14;
		else if (n.contains("pro")) base += 8;
		return base;
	}
}
