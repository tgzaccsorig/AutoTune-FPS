package dev.autotune;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Файл настроек мода: config/autotune.json */
public final class AutoTuneConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	/** Подстраивать прорисовку на лету под FPS. */
	public boolean adaptive = true;
	/** Целевой FPS для автоподстройки. */
	public int targetFps = 60;
	/** Показывать короткие сообщения над хотбаром, когда мод меняет прорисовку. */
	public boolean showMessages = true;
	/** true = менять ВСЕ настройки видео (FPS, VSync, мипмапы, чанки, эффекты, размытие меню). false = только прорисовку, симуляцию и графику. */
	public boolean applyAllSettings = true;
	/** true = пересчитывать настройки при каждом запуске игры (затирает твои ручные настройки). */
	public boolean reapplyEveryLaunch = false;
	/** AUTO или принудительно: POTATO, LOW, MEDIUM, HIGH, ULTRA. */
	public String forceTier = "AUTO";

	// служебное, руками не трогать
	public String hardwareSignature = "";
	public int viewCeiling = 0;

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("autotune.json");
	}

	public static AutoTuneConfig load() {
		Path p = path();
		if (Files.exists(p)) {
			try (Reader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
				AutoTuneConfig c = GSON.fromJson(r, AutoTuneConfig.class);
				if (c != null) return c;
			} catch (Exception e) {
				AutoTuneMod.LOG.warn("Не смог прочитать autotune.json, беру настройки по умолчанию", e);
			}
		}
		AutoTuneConfig c = new AutoTuneConfig();
		c.save();
		return c;
	}

	public void save() {
		try (Writer w = Files.newBufferedWriter(path(), StandardCharsets.UTF_8)) {
			GSON.toJson(this, w);
		} catch (Exception e) {
			AutoTuneMod.LOG.warn("Не смог сохранить autotune.json", e);
		}
	}
}
