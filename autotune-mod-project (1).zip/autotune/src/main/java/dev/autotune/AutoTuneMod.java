package dev.autotune;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class AutoTuneMod implements ClientModInitializer {
	public static final String MOD_ID = "autotune";
	public static final Logger LOG = LoggerFactory.getLogger(MOD_ID);

	/** Сколько тиков (20 = 1 сек) ждать после входа в мир, пока подгрузятся чанки. */
	private static final int WARMUP_TICKS = 20 * 20;
	/** Как часто замерять FPS. */
	private static final int SAMPLE_EVERY = 20;
	/** Сколько замеров усреднять перед решением (10 замеров = ~10 сек). */
	private static final int SAMPLES_PER_DECISION = 10;

	private AutoTuneConfig config;
	private HardwareInfo hw;
	private Tier tier;
	private int heapCap = 32;
	private KeyBinding retuneKey;

	private boolean initialized;
	private boolean failed;
	private final List<String> pendingMessages = new ArrayList<>();

	// автоподстройка
	private ClientWorld lastWorld;
	private int worldTicks;
	private final List<Integer> samples = new ArrayList<>();
	/** Значение прорисовки, которое выставил сам мод (-1 = ещё не знаем). */
	private int modValue = -1;

	@Override
	public void onInitializeClient() {
		config = AutoTuneConfig.load();
		LOG.info("AutoTune загружен, жду конца загрузки игры");
		retuneKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.autotune.retune", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.autotune"));
		ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
	}

	private void onTick(MinecraftClient client) {
		if (failed) return;
		try {
			if (!initialized) {
				// ждём, пока игра закончит загрузку (пропадёт красный экран Mojang)
				if (client.getOverlay() != null || client.options == null) return;
				initialized = true;
				firstSetup(client);
				return;
			}
			if (hw == null) return;

			while (retuneKey.wasPressed()) {
				retune(client);
			}

			if (!pendingMessages.isEmpty() && client.player != null) {
				for (String line : pendingMessages) {
					client.player.sendMessage(Text.literal(line), false);
				}
				pendingMessages.clear();
			}

			if (config.adaptive) {
				adaptive(client);
			}
		} catch (Throwable t) {
			failed = true;
			LOG.error("AutoTune сломался и отключён до перезапуска игры", t);
		}
	}

	// ------------------------------------------------------------------ первая настройка

	private void firstSetup(MinecraftClient client) {
		hw = HardwareInfo.detect();
		heapCap = hw.heapViewCap();
		tier = resolveTier();
		LOG.info("Видеокарта: {} | потоков CPU: {} | ОЗУ: {} МБ | куча игры: {} МБ | баллы GPU/CPU/ОЗУ/итого: {}/{}/{}/{} | уровень: {}",
				hw.gpuName, hw.cpuThreads, hw.physicalRamMb, hw.heapMb,
				hw.gpuScore, hw.cpuScore, hw.ramScore, hw.totalScore, tier);

		String sig = hw.signature();
		if (config.reapplyEveryLaunch || !sig.equals(config.hardwareSignature)) {
			apply(client);
			config.hardwareSignature = sig;
			config.save();
			pendingMessages.addAll(describe("Подобрал настройки под твоё железо."));
		} else {
			// мод уже настраивал это железо раньше: просто даём знать, что он работает
			pendingMessages.add("[AutoTune] работает. Уровень: " + tier.title + ", прорисовка "
					+ client.options.getViewDistance().getValue() + ", симуляция "
					+ client.options.getSimulationDistance().getValue()
					+ ". Пересчитать: клавиша в Управлении → AutoTune.");
		}
	}

	private Tier resolveTier() {
		String forced = config.forceTier == null ? "AUTO" : config.forceTier.trim().toUpperCase();
		if (!forced.equals("AUTO")) {
			try {
				return Tier.valueOf(forced);
			} catch (IllegalArgumentException e) {
				LOG.warn("forceTier '{}' не понятен, использую AUTO", config.forceTier);
			}
		}
		return Tier.fromScore(hw.totalScore);
	}

	private void retune(MinecraftClient client) {
		tier = resolveTier();
		apply(client);
		config.save();
		List<String> lines = describe("Пересчитал настройки.");
		if (client.player != null) {
			for (String line : lines) client.player.sendMessage(Text.literal(line), false);
		}
	}

	private List<String> describe(String header) {
		List<String> lines = new ArrayList<>();
		lines.add("[AutoTune] " + header);
		lines.add("Видеокарта: " + hw.gpuName + " | потоков CPU: " + hw.cpuThreads
				+ " | ОЗУ: " + Math.round(hw.physicalRamMb / 1024.0) + " ГБ");
		lines.add("Уровень: " + tier.title + " — прорисовка " + effView() + ", симуляция " + effSim() + ".");
		if (config.applyAllSettings) {
			lines.add("Ещё выставил: лимит FPS " + (tier.maxFps >= 260 ? "без ограничения" : tier.maxFps)
					+ ", VSync " + (tier.vsync ? "вкл" : "выкл") + ", мипмапы " + tier.mipmaps
					+ ", эффекты экрана и размытие меню.");
		}
		if (heapCap < tier.viewDistance) {
			lines.add("Игре выделено мало памяти (" + hw.heapMb + " МБ), поэтому прорисовку ограничил. "
					+ "Дай игре 4+ ГБ в настройках лаунчера (аргумент -Xmx4G), будет лучше.");
		}
		lines.add("Дальше мод сам подгоняет прорисовку под FPS. Настройки: config/autotune.json");
		return lines;
	}

	// ------------------------------------------------------------------ применение настроек

	private int effView() {
		return Math.max(2, Math.min(tier.viewDistance, heapCap));
	}

	private int effSim() {
		return Math.max(5, Math.min(tier.simDistance, effView()));
	}

	private void apply(MinecraftClient client) {
		GameOptions o = client.options;
		int view = effView();
		o.getViewDistance().setValue(view);
		o.getSimulationDistance().setValue(Math.max(5, Math.min(tier.simDistance, view)));
		o.getGraphicsMode().setValue(tier.graphics);
		o.getCloudRenderMode().setValue(tier.clouds);
		o.getParticles().setValue(tier.particles);
		o.getEntityDistanceScaling().setValue(tier.entityDistance);
		o.getBiomeBlendRadius().setValue(tier.biomeBlend);
		o.getEntityShadows().setValue(tier.entityShadows);
		o.getAo().setValue(tier.ambientOcclusion);
		if (config.applyAllSettings) {
			o.getMaxFps().setValue(tier.maxFps);
			o.getEnableVsync().setValue(tier.vsync);
			o.getMipmapLevels().setValue(tier.mipmaps);
			o.getChunkBuilderMode().setValue(tier.chunkBuilder);
			o.getFovEffectScale().setValue(tier.fovEffects);
			o.getDistortionEffectScale().setValue(tier.distortionEffects);
			o.getMenuBackgroundBlurriness().setValue(tier.menuBlur);
		}
		o.write();

		modValue = view;
		config.viewCeiling = view;
		LOG.info("Применил уровень {}: прорисовка {}, симуляция {}", tier, view, effSim());
	}

	private void setDistances(GameOptions o, int view) {
		o.getViewDistance().setValue(view);
		o.getSimulationDistance().setValue(Math.max(5, Math.min(tier.simDistance, view)));
		o.write();
		modValue = view;
	}

	// ------------------------------------------------------------------ автоподстройка под FPS

	private void adaptive(MinecraftClient client) {
		ClientWorld world = client.world;
		if (world == null || client.player == null) {
			lastWorld = null;
			return;
		}
		if (world != lastWorld) {
			lastWorld = world;
			worldTicks = 0;
			samples.clear();
		}
		worldTicks++;

		// меряем только в чистом геймплее: без меню/инвентаря и после прогрева
		if (worldTicks < WARMUP_TICKS || client.currentScreen != null) return;
		if (worldTicks % SAMPLE_EVERY != 0) return;

		samples.add(client.getCurrentFps());
		if (samples.size() < SAMPLES_PER_DECISION) return;

		double sum = 0;
		for (int s : samples) sum += s;
		double avg = sum / samples.size();
		samples.clear();

		GameOptions o = client.options;
		int cur = o.getViewDistance().getValue();

		// если игрок сам поменял прорисовку — уважаем его выбор как потолок
		if (modValue == -1) {
			modValue = cur;
		} else if (cur != modValue) {
			modValue = cur;
			config.viewCeiling = cur;
			config.save();
		}

		int lower = Math.max(4, tier.viewDistance / 2);
		int ceiling = config.viewCeiling > 0 ? config.viewCeiling : effView();
		int upper = Math.min(Math.min(heapCap, 32), ceiling);

		int next = cur;
		if (avg < config.targetFps * 0.85 && cur > lower) {
			next = cur - 1;
		} else if (avg > config.targetFps * 1.5 && cur < upper) {
			next = cur + 1;
		}

		if (next != cur) {
			setDistances(o, next);
			LOG.info("FPS в среднем {} — прорисовка {} -> {}", Math.round(avg), cur, next);
			if (config.showMessages) {
				client.player.sendMessage(Text.literal("[AutoTune] FPS ~" + Math.round(avg)
						+ ": прорисовка " + cur + " → " + next), true);
			}
		}
	}
}
