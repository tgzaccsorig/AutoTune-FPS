package dev.autotune;

import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.render.ChunkBuilderMode;
import net.minecraft.particle.ParticlesMode;

/** Уровни настроек. Чем выше балл железа, тем выше уровень. */
public enum Tier {
	//                 название    view sim  графика             облака                частицы                  сущности blend тени   ao     fps  vsync  mip  чанки                          fov  искаж. блюр
	POTATO("Картошка",  6,  5, GraphicsMode.FAST,  CloudRenderMode.OFF,  ParticlesMode.MINIMAL,  0.5,  0, false, false, 260, false, 0, ChunkBuilderMode.NONE,            0.0, 0.0, 0),
	LOW("Слабое",       8,  6, GraphicsMode.FAST,  CloudRenderMode.FAST, ParticlesMode.DECREASED, 0.75, 1, false, true,  260, false, 1, ChunkBuilderMode.NONE,            0.5, 0.5, 0),
	MEDIUM("Среднее",  12,  8, GraphicsMode.FANCY, CloudRenderMode.FAST, ParticlesMode.ALL,       1.0,  3, true,  true,  260, false, 2, ChunkBuilderMode.NONE,            1.0, 1.0, 2),
	HIGH("Мощное",     16, 12, GraphicsMode.FANCY, CloudRenderMode.FANCY, ParticlesMode.ALL,      1.0,  5, true,  true,  260, true,  4, ChunkBuilderMode.PLAYER_AFFECTED, 1.0, 1.0, 5),
	ULTRA("Топ",       24, 16, GraphicsMode.FANCY, CloudRenderMode.FANCY, ParticlesMode.ALL,      1.25, 7, true,  true,  260, true,  4, ChunkBuilderMode.PLAYER_AFFECTED, 1.0, 1.0, 5);

	public final String title;
	public final int viewDistance;
	public final int simDistance;
	public final GraphicsMode graphics;
	public final CloudRenderMode clouds;
	public final ParticlesMode particles;
	public final double entityDistance;
	public final int biomeBlend;
	public final boolean entityShadows;
	public final boolean ambientOcclusion;
	/** Лимит FPS. 260 в игре означает «без ограничения». */
	public final int maxFps;
	public final boolean vsync;
	/** Уровни мипмапов 0..4. */
	public final int mipmaps;
	public final ChunkBuilderMode chunkBuilder;
	/** Эффекты изменения поля зрения (спринт, зелья) 0..1. */
	public final double fovEffects;
	/** Эффекты искажения экрана (тошнота, портал) 0..1. */
	public final double distortionEffects;
	/** Размытие фона в меню 0..10. */
	public final int menuBlur;

	Tier(String title, int viewDistance, int simDistance, GraphicsMode graphics, CloudRenderMode clouds,
		 ParticlesMode particles, double entityDistance, int biomeBlend, boolean entityShadows, boolean ambientOcclusion,
		 int maxFps, boolean vsync, int mipmaps, ChunkBuilderMode chunkBuilder,
		 double fovEffects, double distortionEffects, int menuBlur) {
		this.title = title;
		this.viewDistance = viewDistance;
		this.simDistance = simDistance;
		this.graphics = graphics;
		this.clouds = clouds;
		this.particles = particles;
		this.entityDistance = entityDistance;
		this.biomeBlend = biomeBlend;
		this.entityShadows = entityShadows;
		this.ambientOcclusion = ambientOcclusion;
		this.maxFps = maxFps;
		this.vsync = vsync;
		this.mipmaps = mipmaps;
		this.chunkBuilder = chunkBuilder;
		this.fovEffects = fovEffects;
		this.distortionEffects = distortionEffects;
		this.menuBlur = menuBlur;
	}

	public static Tier fromScore(int score) {
		if (score < 25) return POTATO;
		if (score < 45) return LOW;
		if (score < 65) return MEDIUM;
		if (score < 82) return HIGH;
		return ULTRA;
	}
}
